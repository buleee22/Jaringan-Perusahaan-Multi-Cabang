# Rencana Pengujian

| No | Skenario | Perintah / Cara | Hasil yang Diharapkan |
|---|---|---|---|
| 1 | PC mendapat IP otomatis (HQ) | `ipconfig` di PC VLAN 10/20/30 | IP sesuai subnet VLAN |
| 2 | PC cabang mendapat IP via relay | `ipconfig` di PC Cabang A/B | IP 192.168.110.x / 192.168.120.x |
| 3 | Inter-VLAN routing | ping PC VLAN 10 → PC VLAN 20 | Reply sukses |
| 4 | Routing antar cabang | ping PC Cabang A → PC Cabang B | Reply sukses |
| 5 | Neighbor OSPF | `show ip ospf neighbor` di R-HQ | 2 neighbor status FULL |
| 6 | Tabel routing | `show ip route ospf` | Rute LAN cabang tampil (O) |
| 7 | Akses internet + NAT | ping 8.8.8.8 dari PC; `show ip nat translations` | Reply sukses; entri NAT muncul |
| 8 | ACL VLAN Tamu | ping PC Tamu → PC Keuangan | Gagal (diblokir) |
| 9 | Tamu ke internet | ping 8.8.8.8 dari PC Tamu | Sukses |
| 10 | Akses SSH | `ssh -l admin 192.168.99.1` | Login berhasil, telnet ditolak |
| 11 | Port security | colokkan PC lain ke port yang sudah terkunci | Pelanggaran tercatat di `show port-security` |
| 12 | Trunk | `show interfaces trunk` di SW-HQ | VLAN 10,20,30,99 aktif, native 99 |
| 13 | Failover (opsional) | matikan link HQ–A, cek ulang routing | Cabang A terputus, cabang lain tetap normal |

Simpan screenshot hasil tiap skenario ke folder `screenshots/`.
